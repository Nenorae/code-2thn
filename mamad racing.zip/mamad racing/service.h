#ifndef SERVICE_H
#define SERVICE_H

void initializeServices();
void orderService();

#endif
