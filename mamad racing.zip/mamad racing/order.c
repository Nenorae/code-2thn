#include <stdio.h>
#include "order.h"
#include "service.h"

void placeOrder()
{
    orderService();
}
