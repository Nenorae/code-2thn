# Sample Hardhat Project

This project demonstrates a basic Hardhat use case. It comes with a sample contract, a test for that contract, and a Hardhat Ignition module that deploys that contract.

Try running some of the following tasks:

```shell
npx hardhat help
npx hardhat test
REPORT_GAS=true npx hardhat test
npx hardhat node
npx hardhat ignition deploy ./ignition/modules/Lock.js
```

hal yang harus diperhatikan saat menggunakan file ini
1. versi dependencies harus sesuai dan saling support 
2. gunakan versi terbaru dari nomicfoundation hardhat-toolbox dengan versi eters 6 keatas
3. instal semua dependencies menggunakan npm install.
4. tidak semua hal yang baru atau versi baru itu stabil
5. baca dokumentasi mengenai perubahan sintaks dan penambahan fitur
6. menambahkan deploy.js untuk mendeploy kontrak ke jaringan local hardhat
7. Mengganti deployed() dengan waitForDeployment() untuk kompatibilitas dengan API ethers.js 6.x.
8. Menambahkan log debugging untuk melacak proses deploy: Alamat kontrak dan Hash transaksi deploy.
9. menambahkan konfigurasi di hardhat.config.js
10. jangan gunakan esm (ekstensi .mjs) dalam config hardhat, menimbulkan error jadi aku pake js saja.
